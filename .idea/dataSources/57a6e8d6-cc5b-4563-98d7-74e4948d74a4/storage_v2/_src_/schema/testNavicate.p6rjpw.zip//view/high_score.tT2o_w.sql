create view high_score as
select `testnavicate`.`student`.`name` AS `name`, `testnavicate`.`student`.`score` AS `score`
from `testnavicate`.`student`;

